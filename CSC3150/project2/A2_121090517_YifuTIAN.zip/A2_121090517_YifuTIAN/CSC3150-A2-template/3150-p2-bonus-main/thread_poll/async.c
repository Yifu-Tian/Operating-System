#include <stdlib.h>
#include <pthread.h>
#include "async.h"
#include "utlist.h"

my_queue_t *thread_pool;
pthread_mutex_t mutexQueue;
pthread_cond_t condQueue;
int thread_num = 0;

void *thread_function(void *args){
    thread_num++;
    int local_num = thread_num;
    printf("Thread %d starts\n", thread_num);
    while(1){
        my_item_t *task;
        pthread_mutex_lock(&mutexQueue);
        while(thread_pool->size == 0){
            pthread_cond_wait(&condQueue, &mutexQueue);
            printf("Thread %d condition wait\n", local_num);
        }
        task = thread_pool->head;
        DL_DELETE(thread_pool->head,thread_pool->head);
        thread_pool->size --;
        pthread_mutex_unlock(&mutexQueue);
        printf("task.args = %d\n", task->args);
        printf("task.taskFunction = %d\n", (task->taskFunction));
        task->taskFunction(task->args);
        free(task);
        printf("done.\n");
    }
}

void async_init(int num_threads) {
    my_queue_t queue = {
        .head = NULL,
        .size = 0
    };
    thread_pool = (my_queue_t*)malloc(sizeof(queue));
    thread_pool->head = NULL;
    thread_pool->size = 0;

    pthread_mutex_init(&mutexQueue, NULL);
    pthread_cond_init(&condQueue, NULL);

    pthread_t threads[num_threads];
    for(int i = 0; i < num_threads ; i++){
        int rc = pthread_create(&threads[i], NULL, &thread_function, NULL);
        if(rc){
            printf("Failed to create pthread %d\n", i);
        }
    }
    return;
}

void async_run(void (*hanlder)(int), int args) {
    my_item_t work_item={
        .args = args,
        .next = NULL,
        .prev = NULL,
        .taskFunction = hanlder
    };
    my_item_t* work_items;
    work_items = (my_item_t*)malloc(sizeof(work_item));
    if (!work_items) {
        // 内存分配失败
        perror("Failed to allocate memory for task");
        return;
    }
    
    work_items->args = args;
    work_items->next = NULL;
    work_items->prev = NULL;
    work_items->taskFunction = hanlder;

    printf("item args = %d\n", work_items->args);
    printf("item taskFunction = %d\n", (work_items->taskFunction));
    pthread_mutex_lock(&mutexQueue);

    printf("enqueue queue.size = %d \n", thread_pool->size);

    DL_APPEND(thread_pool->head, work_items);

    thread_pool->size ++;

    pthread_mutex_unlock(&mutexQueue);

    pthread_cond_signal(&condQueue);

    return;
}