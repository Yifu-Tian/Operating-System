#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <curses.h>
#include <termios.h>
#include <fcntl.h>

#define ROW 10
#define COLUMN 50 
#define LOGLENGTH 10    
#define LOGLENGTHVAR 25    
#define SPEED 100000
#define WIN 1
#define LOSE 2
#define EXIT 3

int FLAG = 0;
int QUIT = 0;
int thread_num = 10;
int * LOGPOS; 
int * LOGLENGTH_ARRAY;
uint8_t GAMESTATUS = 0;  
uint8_t BOUND = 0;
char map[ROW+10][COLUMN] ;

const char *messages[4] = {
	NULL,
	"You win the game!",
	"You lose the game!",
	"You quit the game!"
};
struct Node{
	int x , y; 
	Node( int _x , int _y ) : x( _x ) , y( _y ) {}; 
	Node(){} ; 
} frog ; 

pthread_mutex_t map_mtx;
pthread_mutex_t frog_mtx;
pthread_mutex_t game_mtx;

void initLogs(){
	// initialize log positions and lengths
    srand(time(NULL));

    LOGPOS = (int*)malloc(sizeof(int) * (ROW-1));
	LOGLENGTH_ARRAY = (int*)malloc(sizeof(int) * (ROW-1));
    for (int i=0; i<ROW-1; i++) {
        LOGPOS[i] = rand() % (COLUMN-1);
		LOGLENGTH_ARRAY[i] = LOGLENGTH + rand() % LOGLENGTHVAR;
		int start = LOGPOS[i];
        int len = LOGLENGTH_ARRAY[i];
        for (int k=0; k<len; k++) {
            map[i+1][(start+k+(COLUMN-1))%(COLUMN-1)] = '=';
        }
    }
    printf("\033[H\033[2J");
}

// Determine a keyboard is hit or not. If yes, return 1. If not, return 0. 
int kbhit(void){
	struct termios oldt, newt;
	int ch;
	int oldf;

	tcgetattr(STDIN_FILENO, &oldt);

	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);

	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);

	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

	ch = getchar();

	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	fcntl(STDIN_FILENO, F_SETFL, oldf);

	if(ch != EOF)
	{
		ungetc(ch, stdin);
		return 1;
	}
	return 0;
}
void changeStatus(int status){
	pthread_mutex_lock(&game_mtx);
	GAMESTATUS = status;
	pthread_mutex_unlock(&game_mtx);
}
void boundSetToOne() {
    pthread_mutex_lock(&game_mtx);
    BOUND = 1;
    pthread_mutex_unlock(&game_mtx);
}
void isOutOfBounds(int x, int y) {
    if (x<0 || x>ROW || y<0 || y>COLUMN-2){
		changeStatus(LOSE);
		boundSetToOne();
	}
}
void hasReachedOtherBank(int x) {
    if (x == 0) changeStatus(WIN);
}
void isInRiver(int x, int y){
	if (map[x][y] == ' ') changeStatus(LOSE);
}
void updateGameStatus(){
	int frogX, frogY;
	pthread_mutex_lock(&frog_mtx);
	frogX = frog.x;
	frogY = frog.y;
	pthread_mutex_unlock(&frog_mtx);
	pthread_mutex_lock(&map_mtx);
	isInRiver(frogX, frogY);
	pthread_mutex_unlock(&map_mtx);
	isOutOfBounds(frogX, frogY);
	hasReachedOtherBank(frogX);
}
bool isGamePlaying(){
	pthread_mutex_lock(&game_mtx);
	int s = GAMESTATUS;
	pthread_mutex_unlock(&game_mtx);
	return (s == 0);
}
void check_and_move_frog(int dx, int dy){
	pthread_mutex_lock(&frog_mtx);
	frog.x += dx;
	frog.y += dy;
	pthread_mutex_unlock(&frog_mtx);
}
void fillMap(int row, int start, int end, int length){
	if (start<=end){
		for (int i = 0; i < start; i++) {
        	map[row][i] = ' ';
		}
		for (int i = start; i < end; i++) {
			map[row][i] = '=';
		}
		for (int i = end; i < length; i++) {
			map[row][i] = ' ';
		}
	}else{
		for (int i=0; i<end; i++){
			map[row][i] = '=';
		}
		for (int i=end; i<start; i++){
			map[row][i] = ' ';
		}
		for (int i=start; i<length; i++){
			map[row][i] = '=';
		}
	}
}
void changeMap_log(int log_id, int start, int log, int frogx, int frogy) {
    int row = log_id + 1;
    int length = COLUMN - 1;
    int end = (start + log) % length;
    pthread_mutex_lock(&map_mtx);
    if (start<=end){
		fillMap(row, start, end, length);
		// change frog
		if (frogx == row){
			if (frogy>=start && frogy<end){
				if (log_id%2) check_and_move_frog(0, 1);
				else check_and_move_frog(0, -1);
			}
		}
	}
    // change frog
    else{
		fillMap(row, start, end, length);
		// change frog
		if (frogx == row){
			if (frogy<end || frogy>=start){
				if (log_id%2) check_and_move_frog(0, 1);
				else check_and_move_frog(0, -1);
			}
		}
	}
    pthread_mutex_unlock(&map_mtx);
}
void getUserInput() {
    printf("\n");  // Ready for user input
    // Read and process user input
}
void cloneMapState(char tmpMap[ROW+10][COLUMN]) {
    pthread_mutex_lock(&map_mtx);
    memcpy(tmpMap, map, sizeof(map));
    pthread_mutex_unlock(&map_mtx);
}
void getCurrentFrogPosition(Node *frogPosition) {
    pthread_mutex_lock(&frog_mtx);
    *frogPosition = frog;
    pthread_mutex_unlock(&frog_mtx);
}
void printMap(char tmpMap[ROW+10][COLUMN], Node curFrogPos){
	
    // Copy the current state of the map to a temporary map
    cloneMapState(tmpMap);

    // Get the current position of the frog
    getCurrentFrogPosition(&curFrogPos);

    // Update the temporary map to show the river banks and the frog
    for(int j = 0; j < COLUMN - 1; ++j) {
		tmpMap[ROW][j] = map[0][j] = '|' ;
        tmpMap[0][j] = map[0][j] = '|' ;  // Draw the banks
    }
    tmpMap[curFrogPos.x][curFrogPos.y] = '0';  // Draw the frog

    // Print the updated map
    printf("\033[H\033[2J");  // Clear the console
    for (int i = 0; i < ROW + 1; i++) {
        puts(tmpMap[i]);
    }
}
void printUpdatedMap() {
    char tmpMap[ROW + 10][COLUMN];
    Node curFrogPos;
	printMap(tmpMap, curFrogPos);
    getUserInput();
}
void *frog_move(void *t){
	while(isGamePlaying()){
		if (kbhit()){
			char move_direction = getchar();
			switch(move_direction){
				case 'w':
				case 'W':
					check_and_move_frog(-1, 0);
					break;
				case 's':
				case 'S':
					check_and_move_frog(1, 0);
					break;
				case 'a':
				case 'A':
					check_and_move_frog(0, -1);
					break;
				case 'd':
				case 'D':
					check_and_move_frog(0, 1);
					break;
				case 'q':
				case 'Q':
					changeStatus(EXIT);
			}
		}
		updateGameStatus();
	}
	pthread_exit(NULL);
}
void *game_control(void *t){
	while (isGamePlaying()){
		printUpdatedMap();
		usleep(SPEED);
	}
	pthread_exit(NULL);
}
int updatePosition(int position, int direction) {
    return (position + direction + COLUMN - 1) % (COLUMN - 1);
}
void copyFrogData(Node *data) {
    pthread_mutex_lock(&frog_mtx);
    *data = frog;
    pthread_mutex_unlock(&frog_mtx);
}
void *logs_move(void *t){
	long id = (long)t;
    int currentPos = LOGPOS[id];
	int logLength = LOGLENGTH_ARRAY[id];
    Node frogState;
    while (isGamePlaying()) {
        int moveDirection = (id % 2) ? 1 : -1;
		currentPos = updatePosition(currentPos, moveDirection);
        copyFrogData(&frogState);
        changeMap_log(id, currentPos, logLength, frogState.x, frogState.y);
        usleep(SPEED);
    }
	pthread_exit(NULL);
}
// Define thread function types
typedef void *(*ThreadFunction)(void *);
// Utility function to create threads
void createThread(pthread_t *thread, ThreadFunction function, void *args) {
    if (pthread_create(thread, NULL, function, args) != 0) {
        perror("Thread creation failed");
    }
}
// Utility function to join threads
void joinThread(pthread_t thread) {
    if (pthread_join(thread, NULL) != 0) {
        perror("Thread join failed");
    }
}
// clean up
void cleanup() {
    pthread_mutex_destroy(&map_mtx);
	pthread_mutex_destroy(&game_mtx);
	free(LOGPOS);
	pthread_exit(NULL);
}
int main( int argc, char *argv[] ){
	// Initialize the river map and frog's starting position
	memset( map , 0, sizeof( map ) ) ;
	int i , j ; 
	for( i = 1; i < ROW; ++i ){	
		for( j = 0; j < COLUMN - 1; ++j )	
			map[i][j] = ' ' ;  
	}	
	for( j = 0; j < COLUMN - 1; ++j )	
		map[ROW][j] = map[0][j] = '|' ;

	for( j = 0; j < COLUMN - 1; ++j )	
		map[0][j] = map[0][j] = '|' ;

	frog = Node( ROW, (COLUMN-1) / 2 ) ; 
	map[frog.x][frog.y] = '0' ; 
	/*************************************************/
	initLogs();
	//Print the map into screen
	for( i = 0; i <= ROW; ++i)	
		puts( map[i] );
	getUserInput();

	pthread_mutex_init(&map_mtx, NULL);
	pthread_mutex_init(&game_mtx, NULL);
	long k;
	/*  Create pthreads for wood move and frog control.  */
	pthread_t threads[ROW+1];

	// Create log threads
	for (k = 0; k < ROW-1; k++) {
		createThread(&threads[k], logs_move, (void*)k);
	}
	// Create frog move control and game status control threads
	createThread(&threads[ROW-1], frog_move, NULL);
	createThread(&threads[ROW], game_control, NULL);
	// Wait for threads to finish
	for (k = 0; k < ROW-1; k++) {
		joinThread(threads[k]);
	}
	joinThread(threads[ROW-1]);
	joinThread(threads[ROW]);
	/* Update game map based on user's game status: win, lose, or quit. */
	if (!BOUND) {
		printUpdatedMap();
		usleep(3*SPEED);
	}
	printf("\033[?25h\033[H\033[2J");
	/*  Display the output for user: win, lose or quit.  */
	if (GAMESTATUS <= EXIT) {
		printf("%s\n", messages[GAMESTATUS]);
	}
	/*****************************/
	cleanup();
	return 0;
}